/****************************************************************/
/* Czekanowski Similarity Metric                                */
/*                                                              */
/* Code Author: Doug Hyatt                                      */
/* Created: June, 2015                                          */
/****************************************************************/

#include "czek.h"

/* Czekanowski Similarity Metric between Two Vectors */
/* v1, v2 = double vectors, len = the size of the vectors */
double czekanowski(int len, double *v1, double *v2) {
  int i = 0;
  double numerator = 0.0;
  double denominator = 0.0;

  for(i = 0; i < len; i++) {
    numerator += (v1[i] < v2[i]?v1[i]:v2[i]);
    denominator += (v1[i] + v2[i]);
  }

  return 2.0*numerator/denominator;
}

/* Process all pairwise combinations of vectors (We do czek(i,j) and */
/* not czek(j,i) since the result is the same. */
void process_vectors(struct _vector *vectors, int numvec, int numfield,
                     FILE *fp) {
  int i = 0;
  int j = 0;
  double czek = 0.0;   /* Value for the Czekanowski Result */

  for (i = 0; i < numvec-1; i++) {
    for (j = i+1; j < numvec; j++) {
      czek = czekanowski(numfield, vectors[i].data, vectors[j].data);
      fprintf(fp, "%s\t%.4f\t%s\n", vectors[i].id, czek, vectors[j].id);
    }  
  }
}

/* Read in the vectors (ids and data) and dynamically allocate */
/* memory as needed. */
struct _vector *read_vectors(FILE *fp, int *numvec, int *numfield) {
  int i = 0;
  int c = 0;               /* Character we read in */
  int field_ctr = 0;       /* Count the number of tab-delimited fields */
  int vec_ctr = 0;         /* Count the number of vectors (lines) */
  int ch_ctr = 0;          /* Counter for individual chars */
  char buf[MAXFIELDSIZE] = "";    /* Buffer for reading fields */
  char *conv_ptr = NULL;   /* Pointer to check conversion */
  struct _vector *vectors = NULL; /* Pointer to the vectors */

  /* Read in the first line to determine the number of fields */
  do {
    c = getc(fp);
    if (c == '\t') field_ctr++;
  } while(c != EOF && c != '\n');
  *numfield = field_ctr;

  /* Now handle various error situations */
  if (feof(fp) != 0) {
    fprintf(stderr, "Read error: Saw end of file before expected.\n");
    return NULL;
  }
  if (ferror(fp) != 0 || c != '\n') {
    fprintf(stderr, "Read error: Error reading the file.\n");
    return NULL;
  }

  /* Allocate initial memory for the vectors and ids */
  vectors = (struct _vector *)malloc(VECCHUNK * sizeof(struct _vector));
  if (vectors == NULL) {
    fprintf(stderr, "Failed to allocate memory for the vectors.\n");
    return NULL;
  }
  for (i = 0; i < VECCHUNK; i++)
    memset(&vectors[i], 0, sizeof(struct _vector));

  /* Read in the remaining lines of the file and add data to the vectors */
  while(c != EOF) {

    /* Allocate memory for a new vector */
    vectors[vec_ctr].data = (double *)malloc(field_ctr*sizeof(double));
    if (vectors[vec_ctr].data == NULL) {
      fprintf(stderr, "Failed to allocate memory for the vectors.\n");
      free_vectors(vectors, vec_ctr);
      return NULL;
    }

    /* Reset field/character counters */
    field_ctr = 0;
    ch_ctr = 0;

    /* Read characters until we hit a tab or newline, then process */
    /* the buffer, either adding it to ID (field 1) or vector data. */
    do {
      c = getc(fp);
      if (c == '\t' || c == '\n') {
        if (field_ctr == 0) vectors[vec_ctr].id[ch_ctr] = '\0';
        else if (field_ctr <= *numfield) {
          buf[ch_ctr] = '\0';
          vectors[vec_ctr].data[field_ctr-1] = strtod(buf, &conv_ptr);
          if (conv_ptr != buf+ch_ctr) {
            fprintf(stderr, "Error converting '%s' to double, line %d.\n",
                    buf, vec_ctr+2);
            free_vectors(vectors, vec_ctr);
            return NULL;
          }
        }
        if (c == '\t') field_ctr++; 
        ch_ctr = 0;
      }
      else if (field_ctr == 0)
        vectors[vec_ctr].id[ch_ctr++] = c;
      else buf[ch_ctr++] = c;
    } while(c != EOF && c != '\n');
    if (c == EOF) break;

    /* If we see wrong number of fields... */
    if (field_ctr != *numfield) {
      fprintf(stderr, "Did not see correct number of fields.\n");
      fprintf(stderr, "Expected %d, saw %d, line %d.\n", *numfield, field_ctr, vec_ctr+2);
      free_vectors(vectors, vec_ctr);
      return NULL;
    }

    /* Increment vector counter.  If hit our limit, realloc for more. */
    vec_ctr++;
    if (vec_ctr%VECCHUNK == 0) {
      vectors = (struct _vector *)realloc(vectors,
                (vec_ctr+VECCHUNK) * sizeof(struct _vector));
      if (vectors == NULL) {
        free_vectors(vectors, vec_ctr);
        fprintf(stderr, "Failed to realloc memory for vectors.\n");
        return NULL;
      }
      for (i = vec_ctr; i < vec_ctr + VECCHUNK; i++)
        memset(&vectors[i], 0, sizeof(struct _vector));
    }
  }
  if (ferror(fp) != 0) {
    fprintf(stderr, "Read error: Error reading the file.\n");
    free_vectors(vectors, vec_ctr);
    return NULL;
  }
  *numvec = vec_ctr;
  return vectors;
}

/* Free routine for vectors */
void free_vectors(struct _vector *vectors, int numvec) {
  int i = 0;

  if (vectors != NULL) {
    for (i = 0; i < numvec; i++)
      if (vectors[i].data != NULL) free(vectors[i].data);
    free(vectors);
  } 
}
