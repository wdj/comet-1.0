/****************************************************************/
/* Czekanowski Similarity Metric                                */
/*                                                              */
/* Code Author: Doug Hyatt                                      */
/* Created: June, 2015                                          */
/****************************************************************/

#ifndef _CZEK_H_
#define _CZEK_H_

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define VECCHUNK 100
#define MAXFIELDSIZE 10000

struct _vector {
  char id[MAXFIELDSIZE];
  double *data;
};

double czekanowski(int, double *, double *);
void process_vectors(struct _vector *, int, int, FILE *);
struct _vector *read_vectors(FILE *, int *, int *);
void free_vectors(struct _vector *, int);

#endif
