#!/usr/bin/perl

$line = <>;
@inf = split /[\t]/, $line;
$s = @inf;
print "size is $s\n";
